"""SQLAlchemy models (architecture section G).

The foundation tables (identity, projects, audit, runs) came with the
foundations phase. The requirements-repository phase adds the requirement,
approval and baseline tables. The knowledge-base phase adds the knowledge corpus
(``normative_source``, ``control``, ``knowledge_item``, ``knowledge_chunk``), the
per-project ``source_allowlist`` and ``evidence``. The extraction phase adds the
project corpus (``source_document``, ``source_chunk``), extraction proposals,
classification, acceptance criteria, the review queue, and prompt and model
provenance. The elicitation phase adds stakeholders, interview sessions,
utterances, quality findings and clarifications. The quality phase adds
conflicts and the project glossary. The compliance phase adds compliance
mappings and their evidence links, compliance gaps, and security/privacy
findings and their evidence links. The risk phase adds the versioned severity
matrix, risk items and their evidence links, and mitigation suggestions. The
approval, traceability and documents phase (P8) adds the typed trace graph
(``traceability_link``) and the generated artefacts (``artifact``,
``artifact_version``, ``artifact_section``). The SDLC recommendation phase (P9)
adds ``sdlc_run``, ``sdlc_factor``, ``sdlc_candidate`` and
``sdlc_rule_application``. The workflow-generation phase (P10) adds ``workflow``,
``workflow_phase``, ``workflow_activity``, ``workflow_gate``, the append-only
provenance ``workflow_source`` and the append-only change log ``workflow_change``.
The guardrails-hardening phase (P11) adds the server-side ``auth_session``
(ADR-009), the separately stored unmasking map ``masking_map_entry`` (J.2) and
the append-only deletion record ``project_purge`` (``FR-ADM-006``).

Tables belonging to later roadmap phases - evaluation - are still deliberately
absent. A test
asserts that the migrations create nothing beyond the tables named here.
"""

from reqpilot.domain.models.approval import ApprovalDecision, ApprovalTask
from reqpilot.domain.models.artifacts import Artifact, ArtifactSection, ArtifactVersion
from reqpilot.domain.models.audit import AuditEvent
from reqpilot.domain.models.base import Base
from reqpilot.domain.models.baseline import Baseline, BaselineMember
from reqpilot.domain.models.compliance import (
    ComplianceGap,
    ComplianceMapping,
    ComplianceMappingEvidence,
    SecurityPrivacyFinding,
    SecurityPrivacyFindingEvidence,
)
from reqpilot.domain.models.elicitation import (
    Clarification,
    InterviewSession,
    QualityFinding,
    Stakeholder,
    Utterance,
)
from reqpilot.domain.models.extraction import (
    AcceptanceCriterion,
    ExtractionCandidate,
    ModelVersion,
    PromptTemplate,
    RequirementClassification,
    ReviewItem,
    SourceChunk,
    SourceDocument,
)
from reqpilot.domain.models.guardrails import AuthSession, MaskingMapEntry, ProjectPurge
from reqpilot.domain.models.identity import Project, ProjectMember, User
from reqpilot.domain.models.knowledge import (
    Control,
    Evidence,
    KnowledgeChunk,
    KnowledgeItem,
    NormativeSource,
    SourceAllowlist,
)
from reqpilot.domain.models.quality import Conflict, GlossaryTerm
from reqpilot.domain.models.requirements import Requirement, RequirementVersion
from reqpilot.domain.models.risk import (
    Risk,
    RiskEvidence,
    RiskMatrixCell,
    RiskMitigation,
)
from reqpilot.domain.models.runs import AgentRun, GraphRun
from reqpilot.domain.models.sdlc import SdlcCandidate, SdlcFactor, SdlcRuleApplication, SdlcRun
from reqpilot.domain.models.traceability import TraceabilityLink
from reqpilot.domain.models.workflow import (
    Workflow,
    WorkflowActivity,
    WorkflowChange,
    WorkflowGate,
    WorkflowPhase,
    WorkflowSource,
)

__all__ = [
    "AcceptanceCriterion",
    "AgentRun",
    "ApprovalDecision",
    "ApprovalTask",
    "Artifact",
    "ArtifactSection",
    "ArtifactVersion",
    "AuditEvent",
    "AuthSession",
    "Base",
    "Baseline",
    "BaselineMember",
    "Clarification",
    "ComplianceGap",
    "ComplianceMapping",
    "ComplianceMappingEvidence",
    "Conflict",
    "Control",
    "Evidence",
    "ExtractionCandidate",
    "GlossaryTerm",
    "GraphRun",
    "InterviewSession",
    "KnowledgeChunk",
    "KnowledgeItem",
    "MaskingMapEntry",
    "ModelVersion",
    "NormativeSource",
    "Project",
    "ProjectMember",
    "ProjectPurge",
    "PromptTemplate",
    "QualityFinding",
    "Requirement",
    "RequirementClassification",
    "RequirementVersion",
    "ReviewItem",
    "Risk",
    "RiskEvidence",
    "RiskMatrixCell",
    "RiskMitigation",
    "SdlcCandidate",
    "SdlcFactor",
    "SdlcRuleApplication",
    "SdlcRun",
    "SecurityPrivacyFinding",
    "SecurityPrivacyFindingEvidence",
    "SourceAllowlist",
    "SourceChunk",
    "SourceDocument",
    "Stakeholder",
    "TraceabilityLink",
    "User",
    "Utterance",
    "Workflow",
    "WorkflowActivity",
    "WorkflowChange",
    "WorkflowGate",
    "WorkflowPhase",
    "WorkflowSource",
]
