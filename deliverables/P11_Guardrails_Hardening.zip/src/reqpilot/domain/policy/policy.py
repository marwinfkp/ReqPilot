"""The authorization policy (architecture ADR-009).

One module, pure functions, no I/O. That combination is what makes
``(role x action x resource)`` assertable as a matrix in a single test file,
which is the property the architecture asks for.

The design rules enforced here rather than trusted to callers:

1. **Deny by default.** An unknown action, an unknown role, or an actor with no
   roles is denied. There is no permissive fallthrough.
2. **Project isolation precedes permission.** An actor is checked against the
   resource's project *before* any role grant is considered, so a correct role
   in the wrong project never yields an allow (``FR-PRJ-004``).
3. **Agent roles can never decide a gate.** Only a human actor holding the
   gate's role may perform ``APPROVAL_DECIDE``. This is the code-level form of
   "an LLM cannot approve its own output" (architecture J.1, M.2).
4. **A gate decision is authorised per gate, never by action grant.**
   ``APPROVAL_DECIDE`` is allowed only for a named gate and a declared role that
   the gate requires (``GATE_REQUIRED_ROLES``) and that the actor holds in the
   resource's project. The bare action is refused, and ``is_superuser`` does not
   substitute for holding the gate's role.
5. **Knowledge curation and grounding scope are human decisions.** No non-human
   actor may administer the knowledge base or change a project's allowlist,
   jurisdictions or KB pin, whatever roles it holds (architecture E.1: agent
   roles write proposals only).
6. **Decisions about AI proposals are human decisions.** From P3 a pipeline acts
   on an analyst's behalf to record what a model proposed. It can never submit a
   requirement for approval, withdraw one, commit a baseline, override a label,
   resolve a review item, merge requirements, add a source or start a run -
   whatever roles it carries (architecture A.1, E.1; ``FR-CLS-003``).
7. **What a stakeholder says is a human's to say.** From P4 the elicitation
   pipeline records the questions the interviewer role proposes. It can never
   answer an interview or a clarification, create a stakeholder or a session,
   record a quality finding, raise or dismiss a clarification, or pause a
   session - whatever roles it carries (architecture E #2, E #4; ``FR-ELI-005``,
   ``FR-CLR-004``). Which *session* a Stakeholder-role user may read or answer -
   only their own - is checked by the elicitation services on top of this.
8. **A detected defect or conflict is a proposal; closing it is a human's call.**
   From P5 the analysis pipeline records what the quality rules and the model
   found (``QUALITY_FINDING_DETECT``, ``CONFLICT_DETECT``). It can never resolve
   or dismiss a finding, take a conflict under review, resolve or dismiss a
   conflict, or edit the project glossary - whatever roles it carries
   (architecture E #6, M.3 G4; ``FR-CNF-005``).
9. **A compliance mapping or a derived security requirement is a proposal; G2
   and G3 are human decisions.** From P6 the analysis pipeline records validated
   candidate mappings, rule-engine gaps and deterministically evaluated
   security/privacy findings (``COMPLIANCE_ANALYSE``, ``SECURITY_ANALYSE``), and
   raises the G2/G3 tasks those persisted values require (``GATE_TASK_RAISE``).
   Raising is not deciding: ``APPROVAL_DECIDE`` stays human-only (rule 3), and only
   the gate's own role - Compliance Officer for G2, Security Reviewer for G3 -
   may decide it (architecture M.3, I.8; ``FR-CMP-004``, ``FR-SEC-003``).
10. **A risk is identified by the pipeline and owned by a human.** From P7 the
    analysis pipeline records identified risks with the severity the
    deterministic matrix computed (``RISK_ANALYSE``) and raises the G8 task a
    persisted HIGH severity requires (``GATE_TASK_RAISE``). It can never accept,
    close, reject or mitigate a risk (``RISK_MANAGE``), and it cannot decide G8:
    that is the Security Reviewer's, through ``APPROVAL_DECIDE`` (approved Phase
    0 F.1's G8 row; architecture I.5; ``FR-RSK-007``, ``FR-RSK-010``).
11. **Documents and trace links are projections, never authority.** From P8 an
    analyst generates artefacts from an approved baseline (``ARTIFACT_GENERATE``)
    and materialises typed trace links from persisted rows (``TRACE_SYNC``).
    Both are human-only: no agent role generates an authoritative document or
    asserts a trace link. Generating an artefact decides nothing about approval,
    baselining or gates - the artefact service reads those from the approval and
    baseline records and refuses when they are missing. Flagging a requirement
    as architecture-critical raises G5 (``ARCHITECTURE_FLAG``); only the Project
    Manager decides it (architecture M.3).
12. **An SDLC recommendation is computed, explained and then decided by four
    humans.** From P9 an analyst starts an SDLC run from an approved baseline
    (``SDLC_RUN_START``); the pipeline records the factor profile, the rule
    applications, the ranking and the explanation (``SDLC_RECORD``) and raises
    G6 (``GATE_TASK_RAISE``). Overriding a factor score (``SDLC_FACTOR_OVERRIDE``,
    the analyst's per F.1 and the Project Manager's per architecture S) and
    asking again for an explanation (``SDLC_EXPLAIN``) are human-only. Nobody can
    set a ranking: G6 is decided per gate (rule 4) by the Project Manager, the
    Architect, the Security Reviewer and the Compliance Officer - all four. The
    Architect role (P9) reads what the Project Manager reads and authors nothing.
13. **A project workflow is generated from a G6 selection, edited by the Project
    Manager, and gates nothing in ReqPilot.** From P10 an analyst or the Project
    Manager asks for the workflow of a G6-selected SDLC run
    (``WORKFLOW_GENERATE``, human only); the pipeline derives, validates and
    records it in the analyst's name (``WORKFLOW_RECORD``). Only the Project
    Manager edits it (``WORKFLOW_EDIT``, human only; ``FR-WFL-007``), and every
    edit is logged. Reading and exporting follow the SDLC readers. Nothing in a
    workflow approves, baselines or decides anything in ReqPilot: its gates -
    production readiness included - are gates of the generated project's own
    process (architecture M.4), and no action here decides G1-G8.
14. **An agent role acts only within its capability token.** From P11 an
    ``AGENT_ROLE`` actor is authorised by the immutable token the Coordinator
    minted for it (architecture P.1, ``[DESIGN] D10``;
    :mod:`reqpilot.domain.capabilities`) and by nothing else: not by any role
    in ``roles_by_project``, not by ``is_superuser``. No token means no access;
    a forged, altered, expired or foreign token means no access; a read, write
    or retrieval the token does not grant is refused. Rules 3 and 5-13 are
    checked first, so no token can reach a gate decision or a human decision.
    Deleting a project (``PROJECT_DELETE``; ``FR-ADM-006``) is a human decision
    too.
"""

from __future__ import annotations

from dataclasses import dataclass, field

from reqpilot.domain.capabilities import Access, CapabilityToken, access_problem
from reqpilot.domain.enums import GATE_REQUIRED_ROLES, Action, ActorKind, Gate, ResourceType, Role
from reqpilot.domain.errors import AuthorizationError, CapabilityError, ProjectIsolationError
from reqpilot.domain.ids import ActorId, ProjectId


@dataclass(frozen=True)
class Actor:
    """Whoever is attempting an action.

    ``roles_by_project`` reflects that a role is held *within a project*, never
    globally - a compliance officer on one project has no standing on another.
    In a small team one person may hold several roles in one project, which is
    why the value is a set.
    """

    actor_id: ActorId
    kind: ActorKind = ActorKind.HUMAN
    roles_by_project: dict[ProjectId, frozenset[Role]] = field(default_factory=dict)
    is_superuser: bool = False
    #: P11: an agent role's grant (architecture P.1). Present only on an
    #: ``AGENT_ROLE`` actor, minted by the Coordinator; never read from a request.
    capability: CapabilityToken | None = field(default=None, repr=False)

    def __post_init__(self) -> None:
        if self.capability is not None and self.kind is not ActorKind.AGENT_ROLE:
            raise ValueError("only an agent-role actor carries a capability token")

    def roles_in(self, project_id: ProjectId | None) -> frozenset[Role]:
        if project_id is None:
            return frozenset()
        return self.roles_by_project.get(project_id, frozenset())


@dataclass(frozen=True)
class ResourceRef:
    """The thing being acted upon.

    ``project_id`` is ``None`` only for resources that genuinely have no project
    scope - creating a project being the obvious case.

    ``gate`` and ``role_exercised`` are the context an ``APPROVAL_DECIDE`` check
    needs: which gate is being decided, and in which role the actor claims to
    decide it. Every other action ignores them, and ``APPROVAL_DECIDE`` without
    them is refused.
    """

    resource_type: ResourceType
    project_id: ProjectId | None = None
    resource_id: str | None = None
    gate: Gate | None = None
    role_exercised: Role | None = None


@dataclass(frozen=True)
class Decision:
    """The outcome of an authorization check.

    Carries a reason because a denial that cannot be explained cannot be audited
    usefully, and because the reason is what a test asserts on.
    """

    allowed: bool
    reason: str
    #: P11: the refusal came from an agent's capability token (rule 14).
    capability_denial: bool = False

    def __bool__(self) -> bool:
        return self.allowed


# ---------------------------------------------------------------------------
# The matrix
# ---------------------------------------------------------------------------

#: Which roles may perform each action. Deny-by-default: an action absent from
#: this mapping is refused (see :func:`can`).
#:
#: ``APPROVAL_DECIDE`` is deliberately absent. Gate decisions are authorised by
#: the gate's own required roles (``GATE_REQUIRED_ROLES``) in
#: :func:`_can_decide_gate`, not by a blanket action grant.
_ACTION_GRANTS: dict[Action, frozenset[Role]] = {
    Action.PROJECT_CREATE: frozenset({Role.ANALYST}),
    Action.PROJECT_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
            Role.KB_ADMIN,
        }
    ),
    Action.PROJECT_DELETE: frozenset({Role.PROJECT_MANAGER}),
    Action.MEMBER_ADD: frozenset({Role.PROJECT_MANAGER}),
    Action.AUDIT_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.AUDIT_VERIFY: frozenset({Role.AUDITOR}),
    Action.RUN_START: frozenset({Role.ANALYST}),
    Action.RUN_RECORD: frozenset({Role.ANALYST}),
    Action.RUN_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    # --- requirements repository -------------------------------------
    # Authoring is the analyst's job. Reviewing roles can read everything in
    # their project but cannot author, which is what keeps the later approval
    # meaningful rather than a rubber stamp.
    Action.REQUIREMENT_CREATE: frozenset({Role.ANALYST}),
    Action.REQUIREMENT_UPDATE: frozenset({Role.ANALYST}),
    Action.REQUIREMENT_TRANSITION: frozenset({Role.ANALYST}),
    Action.REQUIREMENT_SUBMIT: frozenset({Role.ANALYST}),
    Action.REQUIREMENT_WITHDRAW: frozenset({Role.ANALYST}),
    Action.REQUIREMENT_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    # P8: the stakeholder reads approval tasks too - an affected stakeholder is a
    # G4 party (architecture M.3) and must be able to see the task they sign.
    Action.APPROVAL_TASK_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    # Committing a baseline is authorised by passing G1, and the actor who
    # completes G1 may be either of its required roles - so both can write the
    # baseline that the gate has just authorised, and nobody else can.
    Action.BASELINE_CREATE: frozenset({Role.ANALYST, Role.COMPLIANCE_OFFICER}),
    Action.BASELINE_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    # --- knowledge base and retrieval ----------------------------------
    # The curated corpus is shared, so reading and curating it is not scoped to
    # a project: it belongs to the Knowledge-Base Administrator (Phase 0 F.1:
    # "add, version, retire knowledge items"). Everyone else reaches knowledge
    # only through a project, and only through that project's allowlist.
    Action.KB_READ: frozenset({Role.KB_ADMIN}),
    Action.KB_ADMINISTER: frozenset({Role.KB_ADMIN}),
    # A project's grounding scope - allowlist, jurisdictions, KB pin - is set by
    # the KB administrator *of that project*. The analyst who runs an analysis
    # cannot widen the sources that ground it.
    Action.KB_SCOPE_MANAGE: frozenset({Role.KB_ADMIN}),
    Action.KB_SCOPE_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
            Role.KB_ADMIN,
        }
    ),
    # The roles whose work is grounded in normative evidence (architecture E.1:
    # compliance and security retrieve; the analyst drives the analysis).
    Action.KB_RETRIEVE: frozenset({Role.ANALYST, Role.COMPLIANCE_OFFICER, Role.SECURITY_REVIEWER}),
    Action.EVIDENCE_CREATE: frozenset(
        {Role.ANALYST, Role.COMPLIANCE_OFFICER, Role.SECURITY_REVIEWER}
    ),
    Action.EVIDENCE_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    # --- project sources, extraction and classification (P3) -------------
    # The analyst owns the requirement set, so the analyst supplies sources,
    # runs extraction and decides what becomes of each AI proposal. Reviewing
    # roles read; they do not author (the P1 principle).
    Action.SOURCE_CREATE: frozenset({Role.ANALYST}),
    Action.SOURCE_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.CLASSIFICATION_PROPOSE: frozenset({Role.ANALYST}),
    Action.CLASSIFICATION_OVERRIDE: frozenset({Role.ANALYST}),
    Action.REVIEW_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.REVIEW_RESOLVE: frozenset({Role.ANALYST}),
    Action.REQUIREMENT_MERGE: frozenset({Role.ANALYST}),
    # --- elicitation and clarification (P4) --------------------------------
    # The analyst runs interviews and owns the open-issues list. A stakeholder
    # answers questions - their own, which the services check - and reads what
    # concerns them. Reviewing roles read.
    Action.STAKEHOLDER_CREATE: frozenset({Role.ANALYST}),
    Action.STAKEHOLDER_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.SESSION_CREATE: frozenset({Role.ANALYST}),
    Action.SESSION_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.SESSION_ANSWER: frozenset({Role.ANALYST, Role.STAKEHOLDER}),
    Action.SESSION_MANAGE: frozenset({Role.ANALYST}),
    Action.UTTERANCE_RECORD: frozenset({Role.ANALYST, Role.STAKEHOLDER}),
    Action.QUALITY_FINDING_CREATE: frozenset({Role.ANALYST}),
    Action.QUALITY_FINDING_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.CLARIFICATION_RAISE: frozenset({Role.ANALYST}),
    Action.CLARIFICATION_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.CLARIFICATION_ANSWER: frozenset({Role.ANALYST, Role.STAKEHOLDER}),
    Action.CLARIFICATION_DISMISS: frozenset({Role.ANALYST}),
    # --- quality and conflict detection (P5) -----------------------------
    # The analyst owns the requirement set: detections are recorded in the
    # analyst's name by the pipeline, and only a human analyst closes them.
    # Everyone who reads requirements reads their findings and conflicts; a
    # stakeholder is one of the "affected stakeholders" of G4 (M.3).
    Action.QUALITY_FINDING_DETECT: frozenset({Role.ANALYST}),
    Action.QUALITY_FINDING_RESOLVE: frozenset({Role.ANALYST}),
    Action.QUALITY_FINDING_DISMISS: frozenset({Role.ANALYST}),
    Action.CONFLICT_DETECT: frozenset({Role.ANALYST}),
    Action.CONFLICT_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.CONFLICT_REVIEW: frozenset({Role.ANALYST}),
    Action.CONFLICT_RESOLVE: frozenset({Role.ANALYST}),
    Action.CONFLICT_DISMISS: frozenset({Role.ANALYST}),
    Action.GLOSSARY_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.GLOSSARY_MANAGE: frozenset({Role.ANALYST}),
    # --- compliance and security analysis (P6) ----------------------------
    # The pipeline records in the analyst's name; nobody records a legal
    # determination, and the gate decisions are authorised per gate (rule 4).
    # Compliance and security views are read by everyone who reviews the set.
    Action.COMPLIANCE_ANALYSE: frozenset({Role.ANALYST}),
    Action.COMPLIANCE_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.SECURITY_ANALYSE: frozenset({Role.ANALYST}),
    Action.SECURITY_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.GATE_TASK_RAISE: frozenset({Role.ANALYST}),
    # --- risk analysis and the risk register (P7) --------------------------
    # The pipeline records identified risks in the analyst's name; the register
    # is read by everyone who reviews the set; and adding, accepting, closing or
    # mitigating a risk is a human decision, held by the roles that own risk
    # (approved Phase 0 F.1: the Risk Owner may be the Security Reviewer or the
    # PM in a small team, and the Analyst owns the requirement set).
    Action.RISK_ANALYSE: frozenset({Role.ANALYST}),
    Action.RISK_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.RISK_MANAGE: frozenset(
        {Role.ANALYST, Role.SECURITY_REVIEWER, Role.PROJECT_MANAGER, Role.COMPLIANCE_OFFICER}
    ),
    # --- approval, traceability and documents (P8) ------------------------
    # Every reviewing role reads the governance view, the trace graph and the
    # artefacts - the stakeholder too, who is a G4 party and reads requirements.
    # Generating and syncing are the analyst's, who owns the requirement set.
    Action.GOVERNANCE_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.ARCHITECTURE_FLAG: frozenset({Role.ANALYST}),
    Action.TRACE_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.TRACE_SYNC: frozenset({Role.ANALYST}),
    Action.ARTIFACT_GENERATE: frozenset({Role.ANALYST}),
    Action.ARTIFACT_READ: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.ARTIFACT_EXPORT: frozenset(
        {
            Role.ANALYST,
            Role.STAKEHOLDER,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    # --- SDLC recommendation (P9) -------------------------------------------
    # The analyst starts a run and owns the factor profile; the pipeline records
    # in the analyst's name; the G6 approvers and the auditor read it.
    Action.SDLC_RUN_START: frozenset({Role.ANALYST}),
    Action.SDLC_RECORD: frozenset({Role.ANALYST}),
    Action.SDLC_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.SDLC_FACTOR_OVERRIDE: frozenset({Role.ANALYST, Role.PROJECT_MANAGER}),
    Action.SDLC_EXPLAIN: frozenset({Role.ANALYST}),
    # --- workflow generation (P10) ------------------------------------------
    # The analyst (who owns the pipeline) or the Project Manager (who owns the
    # workflow, F.1) asks for it; the pipeline records it in the analyst's name;
    # only the Project Manager edits it (FR-WFL-007).
    Action.WORKFLOW_GENERATE: frozenset({Role.ANALYST, Role.PROJECT_MANAGER}),
    Action.WORKFLOW_RECORD: frozenset({Role.ANALYST}),
    Action.WORKFLOW_READ: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
        }
    ),
    Action.WORKFLOW_EDIT: frozenset({Role.PROJECT_MANAGER}),
    # Listed with the Architect explicitly: the P9 derivation grants the Architect
    # the Project Manager's ``*.read`` actions and ``ARTIFACT_EXPORT`` only.
    Action.WORKFLOW_EXPORT: frozenset(
        {
            Role.ANALYST,
            Role.COMPLIANCE_OFFICER,
            Role.SECURITY_REVIEWER,
            Role.PROJECT_MANAGER,
            Role.AUDITOR,
            Role.ARCHITECT,
        }
    ),
}

#: P9: the Architect is a reviewing role (a G6 approver). It is granted every
#: read the Project Manager holds - so it can see what it signs - and nothing
#: that authors, manages or records. Derived rather than listed so the two can
#: never drift apart.
_ARCHITECT_READS: frozenset[Action] = frozenset(
    action
    for action, roles in _ACTION_GRANTS.items()
    if Role.PROJECT_MANAGER in roles
    and (action.value.endswith(".read") or action is Action.ARTIFACT_EXPORT)
)
_ACTION_GRANTS = {
    action: (roles | {Role.ARCHITECT}) if action in _ARCHITECT_READS else roles
    for action, roles in _ACTION_GRANTS.items()
}

#: Actions an actor may perform without belonging to a project. For these the
#: actor's roles across all projects are considered together.
_UNSCOPED_ACTIONS: frozenset[Action] = frozenset(
    {Action.PROJECT_CREATE, Action.KB_READ, Action.KB_ADMINISTER}
)

#: The Auditor is read-only by construction (approved Phase 0 F.1). Listing the
#: permitted actions positively means a new mutating action is refused for
#: Auditors by default rather than having to be remembered.
_AUDITOR_READ_ONLY_ACTIONS: frozenset[Action] = frozenset(
    {
        Action.PROJECT_READ,
        Action.AUDIT_READ,
        Action.AUDIT_VERIFY,
        Action.RUN_READ,
        Action.REQUIREMENT_READ,
        Action.APPROVAL_TASK_READ,
        Action.BASELINE_READ,
        Action.KB_SCOPE_READ,
        Action.EVIDENCE_READ,
        Action.SOURCE_READ,
        Action.REVIEW_READ,
        Action.STAKEHOLDER_READ,
        Action.SESSION_READ,
        Action.QUALITY_FINDING_READ,
        Action.CLARIFICATION_READ,
        Action.CONFLICT_READ,
        Action.GLOSSARY_READ,
        Action.COMPLIANCE_READ,
        Action.SECURITY_READ,
        Action.RISK_READ,
        Action.GOVERNANCE_READ,
        Action.TRACE_READ,
        Action.ARTIFACT_READ,
        Action.ARTIFACT_EXPORT,
        Action.SDLC_READ,
        Action.WORKFLOW_READ,
        Action.WORKFLOW_EXPORT,
    }
)


#: Actions no non-human actor may perform, whatever roles it holds: curating the
#: shared corpus and changing a project's grounding scope (architecture E.1),
#: and every decision about an AI proposal or the approval path (rule 6).
_HUMAN_ONLY_ACTIONS: frozenset[Action] = frozenset(
    {
        Action.KB_ADMINISTER,
        Action.KB_SCOPE_MANAGE,
        Action.REQUIREMENT_SUBMIT,
        Action.REQUIREMENT_WITHDRAW,
        Action.BASELINE_CREATE,
        Action.CLASSIFICATION_OVERRIDE,
        Action.REVIEW_RESOLVE,
        Action.REQUIREMENT_MERGE,
        Action.SOURCE_CREATE,
        Action.RUN_START,
        # Rule 7 (P4): elicitation decisions and answers are human.
        Action.STAKEHOLDER_CREATE,
        Action.SESSION_CREATE,
        Action.SESSION_ANSWER,
        Action.SESSION_MANAGE,
        Action.QUALITY_FINDING_CREATE,
        Action.CLARIFICATION_RAISE,
        Action.CLARIFICATION_ANSWER,
        Action.CLARIFICATION_DISMISS,
        # Rule 8 (P5): closing a detected defect or conflict is a human decision.
        Action.QUALITY_FINDING_RESOLVE,
        Action.QUALITY_FINDING_DISMISS,
        Action.CONFLICT_REVIEW,
        Action.CONFLICT_RESOLVE,
        Action.CONFLICT_DISMISS,
        Action.GLOSSARY_MANAGE,
        # Rule 10 (P7): accepting, closing or mitigating a risk is a human's call.
        Action.RISK_MANAGE,
        # Rule 11 (P8): no agent role generates an authoritative artefact, asserts
        # a trace link or flags a requirement for a gate.
        Action.ARTIFACT_GENERATE,
        Action.TRACE_SYNC,
        Action.ARCHITECTURE_FLAG,
        # Rule 12 (P9): starting an SDLC run, overriding a factor and asking for an
        # explanation are human; no agent role reorders or re-scores anything.
        Action.SDLC_RUN_START,
        Action.SDLC_FACTOR_OVERRIDE,
        Action.SDLC_EXPLAIN,
        # Rule 13 (P10): asking for a workflow and editing it are human.
        Action.WORKFLOW_GENERATE,
        Action.WORKFLOW_EDIT,
        # Rule 14 (P11): deleting a project and its content is a human decision.
        Action.PROJECT_DELETE,
    }
)


def _access_for(action: Action) -> Access:
    """How an action touches its resource, for an agent's capability check."""
    if action is Action.KB_RETRIEVE:
        return Access.RETRIEVE
    if action.value.endswith(".read"):
        return Access.READ
    return Access.WRITE


#: Actions no agent role performs whatever its token grants: reading or verifying
#: the audit trail, membership and project administration (architecture E.1, P.1).
_AGENT_NEVER: frozenset[Action] = frozenset(
    {
        Action.AUDIT_READ,
        Action.AUDIT_VERIFY,
        Action.MEMBER_ADD,
        Action.PROJECT_CREATE,
        Action.PROJECT_DELETE,
    }
)


def _can_agent(actor: Actor, action: Action, resource: ResourceRef) -> Decision:
    """Rule 14: an agent-role actor is authorised by its capability token alone."""
    if action in _UNSCOPED_ACTIONS or action in _AGENT_NEVER:
        return Decision(
            False,
            f"no agent role performs {action}: it is a human decision (policy rules 5, 14)",
            capability_denial=True,
        )
    problem = access_problem(
        actor.capability,
        project_id=resource.project_id,
        resource_type=resource.resource_type,
        access=_access_for(action),
        resource_id=resource.resource_id,
    )
    if problem is None:
        return Decision(True, f"granted by the capability token of {actor.capability.role}")  # type: ignore[union-attr]
    if "another project" in problem:
        problem += " (project isolation)"
    return Decision(False, problem, capability_denial=True)


def can(actor: Actor, action: Action, resource: ResourceRef) -> Decision:
    """Return whether ``actor`` may perform ``action`` on ``resource``.

    The single authorization entry point. Pure, deterministic, no I/O, so it is
    exhaustively testable and callable from both the API layer and the
    repository layer (the architecture requires both - a missed endpoint
    decorator must not be able to leak data).
    """
    # Agent roles can never decide a gate. Checked first so that no later branch
    # can grant it (architecture J.1, M.2).
    if action is Action.APPROVAL_DECIDE and actor.kind is not ActorKind.HUMAN:
        return Decision(False, f"{actor.kind} actors can never decide an approval gate")

    # Curating the knowledge base and setting what a project may be grounded in
    # are human decisions: no agent role writes anything but proposals
    # (architecture E.1). Checked before any grant, like the gate rule above.
    if action in _HUMAN_ONLY_ACTIONS and actor.kind is not ActorKind.HUMAN:
        return Decision(
            False, f"{actor.kind} actors cannot perform {action}; it is a human decision"
        )

    if not isinstance(action, Action):  # pragma: no cover - defensive
        return Decision(False, "unknown action")

    # Rule 14 (P11): an agent role holds a token, not roles. Evaluated before the
    # superuser shortcut and every role grant, so neither can stand in for it.
    if actor.kind is ActorKind.AGENT_ROLE:
        return _can_agent(actor, action, resource)

    # Gate decisions are authorised per gate against GATE_REQUIRED_ROLES, not by
    # a blanket action grant. Evaluated before the superuser shortcut so that no
    # flag can stand in for holding the gate's role.
    if action is Action.APPROVAL_DECIDE:
        return _can_decide_gate(actor, resource)

    if actor.is_superuser:
        return Decision(True, "superuser")

    grants = _ACTION_GRANTS.get(action)
    if grants is None:
        return Decision(False, f"action {action} has no grant defined; denied by default")

    # Project isolation is evaluated before permission.
    if action not in _UNSCOPED_ACTIONS:
        if resource.project_id is None:
            return Decision(False, f"action {action} requires a project-scoped resource")
        actor_roles = actor.roles_in(resource.project_id)
        if not actor_roles:
            return Decision(
                False, "actor holds no role in the resource's project (project isolation)"
            )
    else:
        actor_roles = (
            frozenset().union(*actor.roles_by_project.values())
            if (actor.roles_by_project)
            else frozenset()
        )
        if not actor_roles:
            return Decision(False, "actor holds no roles")

    if Role.AUDITOR in actor_roles and action not in _AUDITOR_READ_ONLY_ACTIONS:
        non_auditor = actor_roles - {Role.AUDITOR}
        if not non_auditor:
            return Decision(False, "auditor role is read-only")

    permitted = actor_roles & grants
    if not permitted:
        return Decision(
            False,
            f"none of the actor's roles {sorted(actor_roles)} may perform {action}",
        )

    return Decision(True, f"granted via role(s) {sorted(permitted)}")


def _can_decide_gate(actor: Actor, resource: ResourceRef) -> Decision:
    """Authorise a human decision at one gate, in one declared role.

    Reached only from :func:`can`, after the non-human refusal. Project isolation
    is evaluated before the gate's roles, as for every other scoped action.
    """
    gate, role = resource.gate, resource.role_exercised
    if gate is None or role is None:
        return Decision(
            False,
            "approval.decide is authorised per-gate, not by action grant; "
            "a gate and the role exercised are required",
        )
    if resource.project_id is None:
        return Decision(
            False, f"action {Action.APPROVAL_DECIDE} requires a project-scoped resource"
        )

    held = actor.roles_in(resource.project_id)
    if not held:
        return Decision(False, "actor holds no role in the resource's project (project isolation)")

    gate_roles = GATE_REQUIRED_ROLES.get(gate, frozenset())
    if role not in gate_roles:
        return Decision(False, f"{role} may not decide {gate}; it requires {sorted(gate_roles)}")
    if role not in held:
        return Decision(False, f"actor does not hold {role} in this project (holds {sorted(held)})")

    return Decision(True, f"{role} may decide {gate}")


def require(actor: Actor, action: Action, resource: ResourceRef) -> None:
    """Raise unless ``actor`` may perform ``action`` on ``resource``.

    The enforcing form of :func:`can`, for call sites that should abort.
    Distinguishes isolation failures from ordinary denials so that callers - and
    the audit log - can tell a cross-project attempt apart from a missing role.
    """
    decision = can(actor, action, resource)
    if decision.allowed:
        return
    if "project isolation" in decision.reason:
        raise ProjectIsolationError(decision.reason)
    if decision.capability_denial:
        raise CapabilityError(decision.reason)
    raise AuthorizationError(decision.reason)
