# ReqPilot

An agentic requirements-engineering and SDLC-recommendation assistant for the
financial sector. University Software Engineering course project.

ReqPilot turns unstructured stakeholder input into a validated, classified,
risk-assessed, compliance-mapped and fully traceable requirement baseline — and
then, from that baseline, produces a justified SDLC recommendation and a
project-specific workflow.

**The framing that constrains everything:** the system automates information
collection and analysis, but responsibility for regulatory interpretation,
requirement approval and SDLC adoption stays with authorised humans. ReqPilot is
advisory. It does not give legal advice, and it does not make lending decisions.

---

## Current status — roadmap phase P11 (Guardrails hardening)

| Stage | State |
|---|---|
| Phase 0 analysis — `docs/01-analysis.md` | Approved |
| Architecture & design — `docs/02-architecture.md` | Approved |
| P0 Foundations — `docs/03-p0-foundations.md` | Complete |
| P1 Requirements repository — `docs/04-p1-requirements-repository.md` | Complete |
| P2 Knowledge base & RAG — `docs/05-p2-knowledge-base-rag.md` | P2 IMPLEMENTATION COMPLETE — ET-06 PENDING: the implementation checklist is complete; the roadmap exit waits on ET-06, which needs the team-curated corpus and 20-question probe and has not been measured |
| P3 Extraction & classification — `docs/06-p3-extraction-classification.md` | P3 COMPLETE — ROADMAP EXIT PASSED: E1 = 0.967 (P = R = F1) with OpenAI `gpt-5.6-luna` on **E1-SYNTHETIC-v1**, a synthetic reference benchmark reviewed by the sole project author. It is not an independently annotated gold standard and not evidence of real-world accuracy. The two author-approved deviations are recorded in docs/06 §20 |
| P4 Elicitation & clarification — `docs/07-p4-elicitation-clarification.md` | P4 COMPLETE — ROADMAP EXIT PASSED: a scripted synthetic persona interview (LangGraph `elicitation_graph` with a real interrupt and PostgreSQL checkpointing) yields a usable requirement set through the P3 path; follow-ups trigger on seeded vague answers within a deterministic bound; answering a clarification creates a new immutable requirement version, never auto-approved |
| P5 Quality & conflict detection — `docs/08-p5-quality-conflict.md` | P5 COMPLETE — ROADMAP EXIT PASSED: deterministic quality rules plus validated model proposals; a bounded deterministic shortlist before any pairwise model call; conflicts as transition guards (D12) that only a human resolves. On **P5-QC-SYNTHETIC-v1** (a synthetic benchmark written by the AI assistant, author review pending) the configured pipeline scored E3 conflict recall 1.00 with no false positives (0/768), and E2 ambiguity P 0.87 / R 1.00 (FP rate 0.15). Not evidence of real-world accuracy |
| P6 Compliance & security analysis — `docs/09-p6-compliance-security.md` | P6 COMPLETE — ROADMAP EXIT PASSED (see the report) |
| P7 Risk analysis & register — `docs/10-p7-risk-analysis.md` | P7 COMPLETE — ROADMAP EXIT PASSED — PROJECT-AUTHOR REVIEW COMPLETED (see the report) |
| P8 Approval, traceability & documents — `docs/11-p8-approval-traceability-documents.md` | P8 COMPLETE — ROADMAP EXIT PASSED — PROJECT-AUTHOR REVIEW COMPLETED: gates G4, G5 and G7 on the one approval service with G1/G2/G3/G8; fail-closed readiness at submission, G1, baseline commit and generation; a typed, append-only trace graph; RTM; SRS (with data and interface sections), user stories, use cases, compliance matrix, risk register, assumptions/dependency register and open-issues list, all deterministic, versioned and exported as Markdown and DOCX; E6 computed (no target exists; first measurement 0.800 on a synthetic scenario baseline; the synthetic E6 benchmark was reviewed by the project author with no substantive label correction and is not independently expert-validated) |
| P9 SDLC recommendation — `docs/12-p9-sdlc-recommendation.md` | P9 COMPLETE — ROADMAP EXIT PASSED — PROJECT-AUTHOR REVIEW COMPLETED: thirteen factors derived from the approved baseline and the governed risk register, with evidence; bounded model proposals and human overrides; weighted MCDA plus four versioned rules; a persisted ranking with reversal analysis; an LLM explanation checked against the ranking; G6 co-approval by Project Manager, Architect, Security Reviewer and Compliance Officer. E9 = 0.167 (2/12) agreement with a **synthetic AI-generated panel**, not a real or independently validated expert panel (no target exists; the benchmark was reviewed by the project author with no substantive correction). The exit criterion names a blind expert panel; the synthetic panel fills it under **deviation P9-3, approved by the project author** (docs/12 §17) |
| P10 Workflow generation — `docs/13-p10-workflow-generation.md` | P10 COMPLETE — ROADMAP EXIT PASSED: the project workflow of the SDLC selection that passed G6, derived deterministically (no model call) from the selected candidate's versioned template - seven distinct phase structures, hybrids keeping their composition - and the project's own records: a compliance checkpoint for every eligible mapping, implementation and verification activities for every recorded mitigation of every HIGH risk, security activities from the derived security requirements, per-phase roles, deliverables, entry/exit criteria, testing and traceability requirements, and a production-readiness gate inside the generated workflow (no ninth ReqPilot gate). Every derived element is linked to its record (N.2 #24-#26); open items are listed, never filled in; Project Manager edits are validated and logged; Markdown and DOCX export through the P8 renderers. The exit test proves the criterion on a high-regulation synthetic project |
| **P11 Guardrails hardening — `docs/14-p11-guardrails-hardening.md`** | **P11 COMPLETE — EXIT CRITERIA PASSED** (offline 2,397 passed; full PostgreSQL suite 2,666 passed, 0 skipped, 0 failed): protective masking of synthetic financial identifiers (pattern + checksum rules) at ingestion, at the LLM gateway and in audit payloads, with the unmasking map stored apart; Q.4 injection tagging (never blocking); per-role capability tokens minted by the Coordinator and checked at the gateway and in the policy; opaque server-side sessions (development sign-in only - no password login or MFA); project deletion that purges content and keeps a tombstone and a redacted audit trail; an audit viewer with filters and requirement/risk replay; database guards on the approval records. The adversarial suite attacks all eight gates through the real paths (28 attempts, 28 exercised, 0 bypasses, offline and on PostgreSQL); it found and fixed a G8 bypass in the P7/P8 lifecycle guard. No ninth ReqPilot gate. P12 is not started |

P0 built the foundation. P1 built the deterministic requirements repository:
immutable requirement versions, a guarded lifecycle, G1 human approval, and
baselines. P2 built the grounding layer: a typed, versioned knowledge base
(C.1 taxonomy), structure-aware chunking with exact offsets, local embeddings,
PostgreSQL + pgvector hybrid retrieval with the source allowlist enforced
**inside the query**, immutable evidence, and exact citation resolution.

P11 hardened the guardrails. Identifiers in project text are masked before
anything is stored or sent (and again at the gateway, and in audit payloads);
every model call must carry a capability token the Coordinator minted for that
exact role and run, and an agent-role actor can read or write only what its
token grants; the approval records refuse forged decisions and statuses in the
ORM and in PostgreSQL; sessions are server-side and revocable; a Project Manager
can delete a project's content while its audit trail is kept, redacted on read;
and any requirement's or risk's history can be replayed from the audit trail
and checked against the record. Authentication is still a development mechanism.

P10 added workflow generation: once G6 has passed, the selected SDLC's
versioned template becomes the project's own workflow, with a compliance
checkpoint for every eligible mapping, an implementation and a verification
activity for every recorded HIGH-risk mitigation, security activities from the
derived security requirements and a production-readiness gate - each linked to
the record it came from. It is validated before it is stored, edited only by the
Project Manager with a logged reason, and exported as Markdown and DOCX. No
model call is made, and no ReqPilot gate is added.

P9 added the SDLC recommendation: a thirteen-factor profile derived by code
from the approved baseline and the governed risk register; bounded model
proposals and human overrides; weighted MCDA and a fixed-order rule pass over
versioned data, persisted before any explanation exists; an LLM explanation
checked field by field against that ranking; and G6, decided by four humans.
The model explains the ranking and never selects the SDLC.

P8 added governance and output: G4 (Analyst plus each affected stakeholder),
G5 (Project Manager) and G7 (Analyst + Compliance Officer) on the existing
approval service; a readiness check that refuses an unapproved or ungoverned
version at submission, at the G1 signature, at baseline commit and at document
generation; a typed, allowlisted, append-only trace graph with an RTM and
coverage (E6); and deterministic, versioned, section-traced artefacts generated
only from an approved baseline and exported as Markdown and DOCX. P8 makes no
model call.

P5 added requirement analysis: deterministic checks for ambiguity,
incompleteness, testability, infeasibility, duplication, missing sources,
undefined acronyms (against a project glossary) and security/privacy signals;
an LLM quality review whose proposals code validates; conflict detection with a
deterministic shortlist, deterministic contradiction rules and LLM adjudication;
and human review. An open conflict blocks VALIDATED and submission for approval,
and only an analyst resolves it. Findings feed the P4 clarification loop.

P4 added interactive elicitation: role-specific interview templates over the
21 §7 topics, a deterministic coverage tracker and follow-up bound, append-only
utterances, pause/resume on a durable checkpoint, and the clarification loop -
a targeted question bound to a requirement and a finding, whose answer
re-runs P3 extraction and creates a new immutable version for human review.
The model only proposes questions and assessments; code decides everything else.

P3 added the first AI capability, in batch mode: one LLM gateway (versioned
prompts, trust-class fencing, egress guards, one bounded repair, record/replay),
the Requirement Extraction and Classification roles as **propose-only**
contracts, deterministic validation that locates every quoted source span
itself, P1-allocated `FR-/NFR-<DOMAIN>-nnn` identifiers, versioned
classifications with human override, and a review queue that is **not**
approval. Nothing an AI run produces moves past `CLASSIFIED`.

**The model provider is OpenAI**, selected at P3 closure (architecture Y). It is
used only when configured: `LLM_PROVIDER=openai`, with `LLM_API_KEY` and
`LLM_MODEL_DEFAULT` in your untracked `.env`, and the SDK installed
(`pip install -e ".[openai]"`). The default is the offline `stub`. E1 was
measured on a synthetic reference benchmark (docs/06 §20). It demonstrates the
pipeline on controlled synthetic data, not production accuracy.
Project content may leave the machine only when its source was masked at
ingestion (P11) or declared synthetic; content stored before P11 is recorded as
not masked and stays on the machine. Documents are generated deterministically
from approved baselines (P8); no model writes them.

**No external LLM API key is needed** to install, migrate, run or test. The
default test suite never reads `.env`. The live OpenAI checks are opt-in and
billable:

```bash
pytest -m llm tests/llm/test_openai_live.py -s
```

---

## Quick start

```bash
python -m venv .venv
.venv/Scripts/activate      # Windows;  source .venv/bin/activate on Unix
pip install -e ".[dev]"
cp .env.example .env
pytest -m "unit or security"
```

That runs the offline suite with no database and no network. To see the
workflow, start the app and open `/ui`:

```bash
uvicorn reqpilot.main:app --reload
```

Retrieval uses the approved local embedding model (`BAAI/bge-small-en-v1.5`,
ADR-005), which is an optional extra. It never downloads at runtime unless
`EMBEDDING_ALLOW_DOWNLOAD=true` is set once:

```bash
pip install -e ".[embeddings]"
```

To load the synthetic, fictional development knowledge base (the actor is a user
holding the Knowledge-Base Administrator role):

```bash
python scripts/seed_kb.py --manifest data/dev/kb_synthetic/manifest.yaml --actor <user id>
```

Retrieval, pgvector and the database triggers need PostgreSQL; their tests skip
visibly without it. With a migrated PostgreSQL 16 + pgvector available:

```bash
REQPILOT_TEST_DATABASE_URL=postgresql+psycopg://reqpilot:reqpilot_local_dev_only@localhost:5432/reqpilot pytest
```

The P11 guardrail checks can be run on their own; `-s` prints the adversarial
suite's table of attempts and outcomes:

```bash
pytest tests/workflow/test_p11_exit_test.py tests/security/test_p11_adversarial.py -s
```

In development, a browser session can be opened at `/ui/login` (a user id - the
same development identity claim as the `X-ReqPilot-Actor` header, disabled in
production), or through `POST /api/v1/auth/sessions`; there is no password login
or MFA. A Project Manager deletes a project's content at
`/ui/projects/<id>/delete` or `DELETE /api/v1/projects/<id>`, and any audit
reader can replay a history at `/ui/requirements/<id>/history` or
`/ui/risks/<id>/history`.

Full setup, including PostgreSQL and migrations, is in
[docs/03-p0-foundations.md](docs/03-p0-foundations.md). What the repository does
and how its governance is enforced is in
[docs/04-p1-requirements-repository.md](docs/04-p1-requirements-repository.md);
the knowledge base and retrieval are in
[docs/05-p2-knowledge-base-rag.md](docs/05-p2-knowledge-base-rag.md); extraction,
classification and the review queue are in
[docs/06-p3-extraction-classification.md](docs/06-p3-extraction-classification.md).

---

## Architecture in one paragraph

A deterministic application owns all state, policy, approval and audit.
LangGraph orchestrates analysis *inside* it. Thirteen conceptual agent roles do
the analytical work; ten of them invoke or use LLM capabilities and three are
fully deterministic. Every model output is a typed proposal that must pass a
validation pipeline before it touches persistent state.

Three rules shape the whole system:

1. **The LLM proposes; deterministic code disposes.**
2. **The LLM never controls graph topology** — routers are plain Python.
3. **Authority fields do not exist in LLM schemas** — a model cannot set a risk
   severity or an SDLC score because those fields are absent from what it emits.

The structural expression of all three is one import rule, enforced in CI:
`domain/`, `repositories/`, `services/` and `retrieval/` may not import
`graph/`, `agents/`, `llm/` or `langgraph`. Two more follow from it: agent roles
may not import repositories, services or the graph (they only propose), and the
LLM gateway depends on no application layer.

---

## Documentation

| Document | Contents |
|---|---|
| [`docs/01-analysis.md`](docs/01-analysis.md) | Approved Phase 0 analysis: scope, 132 requirements, evaluation plan, P0–P12 roadmap |
| [`docs/02-architecture.md`](docs/02-architecture.md) | Approved architecture: components, 12 ADRs, LangGraph design, data model, HITL, security |
| [`docs/03-p0-foundations.md`](docs/03-p0-foundations.md) | What P0 built, how to run it, and what it deliberately does not do |
| [`docs/04-p1-requirements-repository.md`](docs/04-p1-requirements-repository.md) | The requirements repository: versions, lifecycle, G1 approval, baselines |
| [`docs/05-p2-knowledge-base-rag.md`](docs/05-p2-knowledge-base-rag.md) | The knowledge base and retrieval: taxonomy, versioning, chunking, hybrid search, allowlist, evidence, citations |
| [`docs/06-p3-extraction-classification.md`](docs/06-p3-extraction-classification.md) | The LLM gateway, extraction and classification contracts, source spans, review queue, human override, and the E1 harness |
| [`docs/07-p4-elicitation-clarification.md`](docs/07-p4-elicitation-clarification.md) | Interactive elicitation and the clarification loop |
| [`docs/08-p5-quality-conflict.md`](docs/08-p5-quality-conflict.md) | Quality findings and conflict detection |
| [`docs/09-p6-compliance-security.md`](docs/09-p6-compliance-security.md) | Compliance mapping and security/privacy analysis |
| [`docs/10-p7-risk-analysis.md`](docs/10-p7-risk-analysis.md) | Risk analysis and the risk register |
| [`docs/11-p8-approval-traceability-documents.md`](docs/11-p8-approval-traceability-documents.md) | Gates G4/G5/G7, baseline readiness, the trace graph, RTM, E6, artefact generation and export |
| [`docs/14-p11-guardrails-hardening.md`](docs/14-p11-guardrails-hardening.md) | Masking, injection defence, capability tokens, sessions, deletion and retention, the audit viewer and replay, the adversarial suite |
| [`docs/problem-statement.md`](docs/problem-statement.md) | Reference copy of the original problem statement |

`Problem Statement.docx` remains the authoritative specification.

---

## Data and safety

- **Synthetic and anonymised data only.** No real customer or financial data
  belongs in this repository.
- **Masking is a control, not a licence.** P11 masks the identifier formats it
  lists before text is stored or sent to a model; it does not recognise names,
  addresses or free-text personal details (docs/14 §7). Real data still does not
  belong here.
- **No secrets in version control.** Configuration is environment-driven;
  `.env.example` contains placeholders only.
- The knowledge base is an educational, evidence-based reference corpus — not an
  authoritative legal decision engine.

See the README in each `data/` subdirectory for what may be committed where.
